---
name: standards-based-grading
description: >
  Transform a university engineering or science course from traditional
  points-based grading to standards-based / specifications grading in the
  "Grading for Growth" tradition (Clark & Talbert). Use this skill whenever a
  professor or instructor wants to redesign a course around standards (mastery
  outcomes), build a bundled letter-grade structure, plan reassessment logistics,
  set up an LMS gradebook for standards, or generate equivalent problem-version
  banks for reassessable standards. Trigger it for requests like "convert my
  course to mastery grading," "help me write standards for my class," "design a
  specifications grading scheme," "set up standards-based grading," "build a
  reassessment schedule," or "make equivalent exam versions for a standard" —
  even when the person doesn't use the exact phrase "standards-based grading."
  It is engineering/science-course oriented but adapts to any quantitative
  discipline.
---

# Standards-Based Grading Course Transformation

This skill guides a course redesign from traditional grading to standards-based /
specifications grading, following the *Grading for Growth* framework (Robert Talbert
& David Clark). It was distilled from a full, real redesign of a junior-level
aerospace propulsion course, and it encodes the **decisions and their reasoning**,
not just templates — because the quality of a standards-based course lives in the
judgment calls at each fork, not in the artifacts themselves.

## The single most important idea

A standards-based course replaces *partial-credit points* with *discrete, reassessable
statements of competency* ("standards"). A student's grade is determined by **how many
standards they have demonstrated mastery of**, not by a weighted average of scores. This
changes everything downstream: what you write, how you schedule, how you grade, and how
the LMS is configured. Keep returning to this: **the grade certifies a bundle of
demonstrated competencies, not an accumulation of points.**

## How to use this skill

Work through the phases in order, but treat them as a **conversation with the instructor**,
not a checklist to execute silently. At each decision fork, surface the tradeoff, give a
recommendation with reasoning, and let the instructor decide. The instructor's discipline
knowledge is authoritative on content; your job is to hold the framework's logic steady and
flag when a choice creates a downstream problem.

The phases:

1. **Inventory & standards design** — turn course content into a set of standards.
2. **Foundational/Applied classification** — classify standards by cognitive task (feeds the grade structure).
3. **Proficiency scale & attempt mechanics** — how a single standard is judged and reassessed.
4. **Grade structure** — the bundled letter-grade ladder.
5. **Sequencing & reassessment logistics** — the calendar, exams, and the end-of-term squeeze.
6. **LMS / gradebook setup** — recording and displaying standard states.
7. **Problem-version banks** — equivalent reassessable problems per standard.

Read the matching reference file when you enter a phase that needs depth. Each reference
is written to be read in full when that phase is active:

- `references/standards_design.md` — writing standards, scope notes, the single-standard purity principle, and the hardest recurring problem (standards that don't want to stand alone).
- `references/grade_structure.md` — bundles, the ladder, plus/minus logic, pass-gates, and the percentage-vs-standards trap.
- `references/scheduling_reassessment.md` — the conservation-of-squeeze principle, exam batching, reassessment windows, and using teaching sequence to protect priority standards.
- `references/lms_setup.md` — gradebook architecture for standards (the status-board model), and why the final grade is entered manually.
- `references/problem_banks.md` — the version-bank template method: axes, difficulty anchoring, de-scaffolding, and equivalence.

## Phase 1 — Inventory & standards design

Goal: convert the course's actual content (homework, past exams, lecture topics) into a
set of **standards** — student-facing "I can…" statements, each with a private **scope note**
that pins down exactly what is and isn't certified.

Start by asking the instructor for their real materials: past exams, homework sets, the
lecture schedule, the syllabus learning outcomes. Analyze what the course *actually assesses*,
not what the catalog says. Group related skills into candidate standards.

Key principles (full detail in `references/standards_design.md`):

- **One standard = one coherent, assessable competency.** Written as "I can [do X]."
- **Direction-agnostic.** If a skill can be tested forward and backward (given A find B, or given B find A), the standard covers both; don't split by direction.
- **Certify the skill, not the tool.** If proctoring is no-computer, don't certify software fluency.
- **Scope notes are the specification.** They tell a grader exactly what counts as "met," and they are where you draw boundaries against adjacent standards.
- **Watch for standards that resist standing alone.** The recurring hard case: a skill your course only ever tests *in combination* with another (e.g., a shock embedded in nozzle flow). `references/standards_design.md` has a full decision procedure for this — it's the subtlest part of the whole design.

Typical output: a numbered list of standards. Number them in **teaching order** if you want
the syllabus to read cleanly (this ripples into the gradebook and problem banks, so decide
early). Compute-type standards and judgment-type standards (met/not-yet, for evaluation/design
reasoning) can coexist; keep them distinguishable.

## Phase 2 — Foundational/Applied classification

Classify each standard by the **kind of cognitive task** it certifies, not by where it
falls in the calendar. A common, useful split:

- **Foundational** — single-phenomenon physics / application of a relation.
- **Applied** — whole-device analysis, system sizing, design-tradeoff judgment.

This is **load-bearing**: the grade structure (Phase 4) is usually built on these bundles, so
the classification must be by genuine cognitive type, not convenience. Resist the temptation to
move a standard into a bundle just to make the numbers work — that corrupts the meaning of the
classification. `references/grade_structure.md` explains how the bundles feed the ladder.

## Phase 3 — Proficiency scale & attempt mechanics

Decide how a *single* standard is judged and reassessed. Typical choices:

- **Compute standards:** a three-level scale — Successful / Minor-revision-needed / New-attempt-required. Only "new attempt" burns an attempt.
- **Judgment standards:** two-level — Met / Not-yet.
- **Attempts:** a fixed ceiling (e.g., 3), "calendar permitting."
- **Practice gate:** whether students must practice before a first attempt. Consider a *self-attested* soft gate (a checkbox affirming practice, unverified) rather than a hard verified gate — it keeps the nudge and the "be ready before you attempt" norm while removing the executive-functioning tax and tracking burden that fall hardest on the students who most need flexibility. See `references/grade_structure.md`.

## Phase 4 — Grade structure

Build the letter-grade ladder from the bundles. Full method, worked examples, and the
crucial "percentage vs. standards" reasoning are in `references/grade_structure.md`. The
essentials:

- Grades are defined by **thresholds on the bundles** (e.g., "A = 8 of 10 Foundational AND all 6 Applied"), not by percentages.
- **A ≠ everything.** Following *Grading for Growth*, the top grade should tolerate a small shortfall — but confine the slack to standards you're willing to let a strong student miss.
- Let both bundles **step down together** as the ladder descends, so each grade boundary means the same kind of thing.
- **Plus/minus:** standards-based grading resists fine gradations. If used at all, a "+" should map to a *discrete achievement* (e.g., cleared this tier and met one requirement of the next), never to a percentage band.
- **Pass-gates:** a standard required for *any* passing grade (common for ethics/professionalism) sits *outside* the bundles as a separate Met requirement, so it doesn't distort the bundle counts.
- **Continuation gates:** if a grade gates entry to a later course, decide whether it names specific required standards or stays a pure count — and record *why* (downstream reteaching, difficulty, simplicity).

## Phase 5 — Sequencing & reassessment logistics

The scheduling reference (`references/scheduling_reassessment.md`) covers the core insight:
**the end-of-term squeeze is a conservation problem.** Whatever is taught last gets the least
reassessment runway; you cannot eliminate this, only decide *which* standard can best tolerate
it. Use teaching sequence deliberately to push the squeeze onto crunch-tolerant, lower-priority
standards and protect your priority standards with early debut + maximum reassessment cycles.

Also covered: batching first attempts into exam events, the weekly reassessment window, using a
reassessment-only final as a safety net, and verifying each exam only assesses standards
*already taught* by that date.

## Phase 6 — LMS / gradebook setup

See `references/lms_setup.md`. The core model: the gradebook is a **status board**, not a
grade calculator. Most LMS gradebooks (Brightspace/D2L, Canvas, etc.) are built for points and
**cannot compute a bundle-rule final grade** — so the standard-state columns are a
record/display layer, and the letter grade is entered manually at checkpoints. The reference
covers the status-column pattern, attempt tracking, consistency across multiple graders, and the
important caveat that LMS specifics vary by institution and version — always tell the instructor
to verify the mechanics with their LMS support team rather than trusting remembered feature details.

## Phase 7 — Problem-version banks

For every reassessable standard you need multiple **equivalent** problem versions (so a student
reattempting gets a fresh problem, and friends can't pass answers). `references/problem_banks.md`
gives the full template method. The essentials:

- Define a **template** per standard: the fixed solution structure plus the axes that may vary (context, sub-type, given/unknown set, solve direction), with **difficulty guardrails** so versions are genuinely equivalent, not just cosmetically different.
- **Anchor difficulty** to a real past exam problem from the instructor — calibrate against it explicitly.
- **De-scaffold:** never tell the student *how* to solve it ("determine X from the Y relation"). Ask only for the quantity. Naming the method defeats a mastery assessment.
- **Verify every number.** Compute answers programmatically and reconcile to whatever reference tables the students actually use (round to the students' table granularity).
- **Alternate problem types** through the bank so adjacent versions differ.
- Count versions by **active reassessment weeks** per standard, not a flat number — early-taught standards need more.
- **Confirm the discipline's conventions before computing** (friction-factor definition, γ / gas constants, ratio direction) — a wrong convention makes every answer systematically wrong while still looking right — and **match the instructor's existing artifact format** (column layout, answer-option wording, instruction boilerplate) instead of imposing your own. See `references/problem_banks.md`.
- **Judgment standards** are built differently: verifiable-direction ones use a bundle of items with a count-based threshold set by the guessing math (and salt in genuine invariant items so no answer option can be eliminated and coin-flipped); open-reasoning ones need a per-item rubric. See the judgment-standard section of `references/standards_design.md`.

## Working style reminders

- This is a **multi-session, iterative** design. Keep a single consolidated design document as the running artifact and update it as decisions are finalized. Re-verify state at the start of a session.
- At every fork, **give a recommendation with reasoning and the honest tradeoff**, then defer to the instructor on content and values.
- When a late decision ripples backward (e.g., merging two standards changes the bundle counts and the ladder), **name the ripple** and offer to recompute rather than silently leaving the document inconsistent.
- Produce professional, branded deliverables (the instructor's institution) when generating documents, and always verify rendered output.
