# LMS / Gradebook Setup

How to make a points-oriented LMS gradebook track standards.

## The core model: status board, not calculator

Most LMS gradebooks (Brightspace/D2L, Canvas, Moodle) are architecturally built around
**points and columns**. What a standards-based course needs is a per-student, per-standard
**state machine**: not-started → practiced → attempt taken (result) → … → mastered/exhausted.
The LMS has no native object for this, and — critically — **it cannot compute your bundle-rule
final grade** (no built-in formula expresses "8 of 10 Foundational AND all 6 Applied AND ethics
Met"). So:

**The gradebook is a record/display layer. The letter grade is entered manually** at checkpoints
by reading the standard states against the ladder. Design the gradebook to make that reading fast,
not to automate it.

## The column pattern

For each standard, use **two grade items**: one **status item** (shows the proficiency level as a
word + color) and one **attempts item** (shows a number — how many reassessments remain). Both are
ordinary **numeric** grade items; the status item borrows a *Grade Scheme* to render its number as a
labeled, colored level. Keep them separate so you can read "which level" and "how many attempts left"
independently, and sort/filter each at scale.

### Verified Brightspace / D2L procedure (Purdue)

This is the concrete build confirmed on Purdue's Brightspace. It replaces the generic advice below;
follow it directly if you're at Purdue, and use it as a close guide elsewhere (menu labels vary
slightly by version).

**Step 1 — Create the Grade Scheme for the proficiency levels.**
Go to **Grades → Schemes → New Scheme**. Add one level (called a *range* / *symbol* in D2L) for each
proficiency value in your scale — e.g., `New attempt required`, `Minor revision needed`, `Successful`.
For each level:
- Set a **Start %**. The numbers only serve as cutoffs that separate the levels; they do **not**
  contribute to any grade and don't need to be meaningful. Just make them ascending (e.g., 0 / 40 / 80).
- Set a **Color** so the level reads at a glance (e.g., red / yellow / green for
  New-attempt / Minor-revision / Successful).
Save the scheme. You reuse this one scheme for every compute standard. (Make a second scheme with
just two levels — e.g., `Not yet` / `Met` — for judgment and ethics standards.)

**Step 2 — Create the status grade item for a standard.**
Go to **Grades → Manage Grades → New → Item → Numeric**. Then:
- **Name** it with the standard's ID (e.g., `C4`).
- Set the item's **Grade Scheme** to the scheme you created in Step 1.
- Under **Display options**, show the students the **Grade scheme symbol** (the proficiency level's
  name) and the **Grade scheme color** — and *not* the points. A grader enters a number that falls in
  a level's range; the student sees the level's word and color (e.g., a green "Successful").
- **Save and Close.**

**Step 3 — Create the remaining-attempts grade item for the same standard.**
Create a second **Numeric** item for the standard (e.g., `C4 attempts`). For this one:
- Show the students the **points grade**, *not* the grade-scheme symbol or color. The student then
  simply sees a number — e.g., `2` meaning two reassessments remain.
- Set **Maximum Points** to the total number of reassessments available (e.g., 3).
Decrement this value as a student uses attempts (per your burn rule — typically only a
"new attempt required" result burns one).

**Step 4 — Housekeeping.**
- Set both items to be **excluded from the calculated final grade** — they are a record/display
  layer, not grade contributors (the bundle-rule letter grade is entered manually; see below).
- Group the items into **Categories** mirroring your bundles (Foundational / Applied / Ethics) so
  that 30+ items stay legible.
- **Pilot one module's worth of items end-to-end** before building all of them: create the items,
  run a mock student through a full attempt-and-reassessment cycle, and confirm the student view shows
  the level+color on the status item and the plain number on the attempts item.

### Why numeric-item-plus-scheme (not free text)

Rendering the level from a numeric item through a shared scheme keeps the labels **fixed and
consistent** across all standards and all graders — it prevents the "Successful" / "success" / "done"
drift that free-text entry produces and that makes the gradebook unfilterable. It also gives you the
color cue for fast visual scanning across hundreds of students.

## Newer "mastery / outcomes" features

Some LMSs have a Learning Outcomes / Competencies system with a "Mastery View" that is *designed*
for this and may fit better than the numeric-item-plus-scheme approach — one outcome per standard, a
custom achievement scale, a purpose-built grid. If the instructor has it and it's enabled, compare it
against the verified item-based build and pick whichever their institution supports more cleanly.
**But** it still almost certainly won't compute the bundle-rule letter grade, so manual final-grade
entry survives regardless.

## The honesty caveat about LMS specifics

The Purdue Brightspace procedure above is verified, but LMS feature behavior varies by product,
version, and institutional configuration (some features are toggled off by the school). Outside
Purdue's Brightspace — or on a different Brightspace version — treat the steps as a close guide, not
gospel, and **don't narrate click-by-click steps from memory as if certain** for a system you can't
see. Give the instructor the *model* (status board, numeric-item-rendered-through-a-scheme for the
level, a separate numeric attempts item, excluded-from-calculation, manual final grade) and the
*specific questions to confirm with their LMS support team*:

- Can students see grade items that are excluded from the final grade?
- Does the grade-scheme symbol + color display correctly to students on a numeric item?
- Is there a bulk/CSV way to create many similarly-structured items at once (vs. clicking each)?
- (If considering a Mastery/Outcomes view instead) Can I define my own achievement scale, use
  different scales for different standard types, and does a grader record levels manually per student
  per outcome?

## Multi-grader hygiene

If several TAs edit the gradebook directly, there is no edit-locking — set a **procedural
protocol**: who owns which windows, and a fixed convention for how a status is recorded. The
picklist columns do most of the consistency work; the protocol handles collisions.

## Artifact persistence

If you build any student-facing tracker or dashboard outside the LMS, remember most sandboxed
artifact environments don't persist browser storage — keep such tools in-session or back them
with a real store; don't rely on localStorage.
