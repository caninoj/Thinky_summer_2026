# Grade Structure

Building the bundled letter-grade ladder, and the reasoning that keeps it sound.

## The bundle model

Grades are defined by **thresholds on bundles of standards**, not percentages. A common
structure uses two bundles from the Foundational/Applied classification, e.g.:

- Foundational bundle (say 10 standards)
- Applied bundle (say 6 standards)

A letter grade states a required count from each: "A = at least 8 of 10 Foundational AND
all 6 Applied."

## Principle: A ≠ everything

*Grading for Growth* argues the top grade should **not** require every standard. The reasons
are about reassessment economics and stress: if an A demands literally everything, one
unmastered standard is indistinguishable from failing, the reassessment system floods at the
margin, and students grind their weakest standard instead of consolidating. A small built-in
slack absorbs noise (a bad exam day, one topic that never clicked).

**But confine the slack to standards you're willing to let a strong student miss.** Don't make
the A "miss any 2 of 16" if two of those are core. Put the slack where you'd genuinely accept a
gap. Often this is one specific low-priority topic; the bundle threshold ("8 of 10") is a blunt
way to grant it, which is fine if you're comfortable with *any* 2 Foundational being the misses.
If you need it surgical (only a specific standard may be skipped), name it explicitly instead of
using a raw count — but that adds complexity, so prefer the blunt count if you can accept it.

## The percentage-vs-standards trap

Instructors instinctively check the bundle thresholds against 90/80/70/60 and worry they're
"too lenient" (e.g., "A = 14/16 = 87.5%, isn't that low for an A?"). **This comparison is
invalid**, and it's important to explain why:

A traditional percentage bakes in *partial credit* — a 90% average includes a lot of "sort of
knew it." A standards count has **no partial credit**: each standard is mastered or not. So
"14 of 16 standards mastered" is 14 things the student can *actually do to your Successful bar* —
a stronger claim than a 90% average that mixed full and partial understanding. The standards
percentage is computed on a stricter dollar; it is *not* comparable to a traditional percentage,
and is generally **stricter** than it looks. Put a sentence to this effect in the syllabus to
preempt the objection from students and colleagues.

Where the percentage lens *does* have teeth: the **bottom** of the scale. A passing D that
certifies only half the standards may be too weak if the course is a prerequisite. Scrutinize the
floor, not the top.

## Building the ladder

Let **both bundles step down together** as grades descend, so every boundary reflects movement
on both axes (avoid a ladder where only one bundle moves — it makes some boundaries meaningless).
Worked example that preserves an Applied-priority intent:

```
A+ = 10/10 F + 6/6 A       (all standards)
A  =  8/10 F + 6/6 A
B  =  7/10 F + 5/6 A
C  =  6/10 F + 4/6 A
D  =  5/10 F + 3/6 A
F  = below D
```

Applied stays required-in-near-full at the top (protecting priority standards), Foundational
carries the slack.

## Plus/minus

Standards-based grading resists fine gradations — a "+" tied to a percentage band reintroduces
exactly the continuous scale the system discards. If you use modifiers at all, tie each to a
**discrete achievement**: e.g., A+ = all standards; and a "+" tier = "cleared this tier AND met
one of the two requirements of the next tier up." Write plus tiers as **explicit locked pairs**,
not a free choice between columns, or students will misread "8/10 F or 7/10 F" crossed with
"5/6 A or 6/6 A" as permitting 8/10+6/6 (which is actually the next grade up). Show each plus
tier as two paired rows joined by "or."

## Pass-gates (ethics/professionalism)

A standard required for *any* passing grade — commonly an ethics reflection — should sit
**outside** both bundles as a separate "must be Met" requirement, not folded into a bundle.
Folding it in lets a student skip it and compensate with another standard (wrong for an ethics
requirement) and distorts the bundle counts the ladder depends on. Display it as its own column
in the ladder showing "Met" required for every grade above F. Assess it appropriately to its type
(a reflection paper is met/not-yet with one revision cycle, not the three-attempt compute mechanic).

## Continuation gates

If a specific grade gates entry to a later course, decide deliberately whether that grade names
**specific required standards** or stays a **pure count**. A pure count is simpler and avoids
double-hard gates, and is often justified because (a) the downstream course reteaches the
material, (b) the gate-relevant standards are among the hardest so requiring all of them pushes
the gate near the top grade, and (c) named-standard gates add syllabus/regrade complexity.
**Record the reasoning** in the design document so it isn't relitigated later. If the downstream
course does *not* reteach and the standards are true hard prerequisites, then naming them is
justified despite the complexity.

## Practice gate (attempt mechanics that touch grading)

Whether students must practice before a first attempt is a real design lever with four settings:
hard verified gate; provided-but-optional; **self-attested soft gate** (checkbox, unverified);
and consequence-shifted (first attempts don't burn an attempt). The self-attested soft gate is
usually the sweet spot: it preserves the "be ready before you attempt" norm and a light commitment
nudge, while removing the verification overhead and the executive-functioning tax that a hard gate
imposes on exactly the students (ADHD, first-gen, working) who most need flexibility. If you doubt
a checkbox changes behavior, just provide the practice and don't pretend to gate. Couple this
decision with the attempt economy: if the soft gate proves too soft and students waste attempts,
the fix is to make first attempts not burn an attempt, not to re-impose a hard gate.
