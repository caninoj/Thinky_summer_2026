# Standards Design

How to turn course content into standards, and how to handle the subtle cases.

## What a standard is

A standard is a **coherent, assessable competency**, written student-facing as an
"I can…" statement, paired with a private **scope note** that specifies exactly what
is certified. Example:

- **Statement:** "I can analyze isentropic flow to relate area, Mach number, and stagnation/static state."
- **Scope note:** "Solve for any unknown among area, Mach, and stagnation/static state, in any direction."

## Core principles

**One standard, one competency.** A standard names a single skill a student either has
or doesn't. Standards may be *composite* (contain sub-steps) as long as the composite is
the thing you actually mean to certify — but resist bundling genuinely distinct skills into
one standard, because you lose diagnostic resolution (the ability to tell a student *what*
they haven't mastered).

**Direction-agnostic.** If the underlying skill can be exercised forward (given A, find B)
or in reverse (given B, find A), one standard covers both directions. Don't split a standard
by solve direction — reversing the process is a valid problem *type*, not a separate standard.

**Certify the skill, not the tool.** Decide what competency you're certifying independent of
software. If exams are no-computer, do not certify tool fluency (CEA, Python, MATLAB); certify
the hand-analysis skill. Conversely if a tool *is* the skill, certify it and proctor accordingly.

**Scope notes are the specification.** The scope note is where you:
- state the allowed solve directions,
- list what's in and explicitly out of scope,
- draw the boundary against adjacent standards,
- set the difficulty/representativeness bar a grader uses for "met."

Write scope notes precisely enough that a GTA grading at 2am applies the same bar you would.

**Compute vs. judgment standards.** Distinguish standards judged by correct computation
(three-level scale) from standards judged by the *quality of reasoning* about a design choice
or evaluation (met/not-yet). Judgment standards ("evaluate a design tradeoff," "predict and
justify a property change") certify engineering judgment, not arithmetic.

## The hardest recurring problem: standards that resist standing alone

The subtlest issue in standards design is a skill your course only ever tests **embedded in
another skill.** Classic example: a normal shock that always appears *inside* a nozzle-flow or
duct-flow problem, never in isolation. This creates a genuine tension with single-standard
assessment. Work through it with this decision procedure:

**Step 1 — Ask: can the skill be assessed in isolation at meaningful difficulty?**
Try to construct a standalone problem. If the standalone version is *trivial* (e.g., a pure
normal-shock problem is a single table lookup — no branch to diagnose, no judgment), that's a
red flag the skill doesn't want to stand alone.

**Step 2 — Look for a discriminating sub-skill unique to the standard.**
Often there's a concept that (a) is genuinely part of this standard and (b) isn't trivial.
Example: across a normal shock the *sonic reference area A\* changes* (because stagnation
pressure drops), so any downstream area calculation must re-reference. A student who doesn't
understand this gets it wrong. That concept can carry the standard's difficulty.

**Step 3 — Check whether the discriminating sub-skill is assessable without the *other* standard.**
This is the crux. Sometimes the discriminating concept *itself* requires the adjacent skill.
(The A\*-change can only be demonstrated by doing a downstream isentropic area calculation —
which is the adjacent standard's skill.) If so, the two standards are genuinely entangled.

**Step 4 — Choose among three resolutions:**

1. **Keep it standalone and accept it's easy.** Legitimate — not every standard must be hard.
   Give the pre-requisite state directly so no adjacent-skill work is needed. The standard
   certifies exactly the narrow skill. Cost: it's a near-gimme, which may feel out of place.

2. **Redefine the standard as the combination, graded narrowly.** Define it as
   "analyze [the combined situation]," but **grade only on the target skill's portion** — treat
   the adjacent skill's work as scaffolding you don't separately penalize. This keeps difficulty
   *and* single-standard purity, but requires a clear grading rule. The clean version: **give the
   pre-requisite state so there's no adjacent work to *reach* the situation, require the target
   skill's downstream consequence, and grade from that point onward.** This is usually the best
   answer.

3. **Merge the two standards.** If grading the whole combined problem (including the adjacent
   skill) is what you actually want, then the standards are not independent and honesty demands
   merging them into one. Cost: reduces the standard count, which shifts the bundle math and the
   grade ladder — recompute them. Only do this if the merged skill is genuinely one competency in
   your mind.

**The tell for which resolution:** ask the instructor — "when you picture a student who has
mastered everything except this skill, is that a distinct, nameable gap, or is it really just a
gap inside the adjacent skill?" A distinct gap → keep separate (resolution 1 or 2). Not distinct →
merge (resolution 3).

**Do not solve an entanglement by moving the standard to a different bundle** (e.g., Foundational→
Applied). Bundle membership is a cognitive-task classification; moving a standard for bookkeeping
reasons corrupts that classification and usually doesn't even fix the entanglement.

## Designing a judgment standard (met / not-yet)

Judgment standards certify reasoning rather than a computed number, so they're built differently
from compute standards. Two sub-types, which need different treatment:

**Type A — verifiable-direction judgment** (e.g., "predict how a flow property changes across a
process"). Each item has a provably correct answer (increase / decrease / no change), but the
*standard* is the pattern of correct reasoning across many varied processes, not any single item.
Build these as a **bundle of items with a count-based threshold**:

- Build a **verified item pool** — compute or reason out the correct answer for every candidate
  item, so the answer key is provably right, then draw versions from the pool.
- Set the pass threshold with the **guessing math**, not by feel. For an item with *k* answer
  options, a pure guesser gets each right with probability 1/*k*; the chance of passing *t* of *n*
  by luck is the binomial tail P(X ≥ t), X ~ Binomial(n, 1/k). Pick *t* so that number is small.
  Worked example: 10 items, 3 options — a pure guesser clears 8/10 only ~0.3% of the time, and
  even a "smart" guesser who eliminates one option and coin-flips (p = 1/2) clears it only ~5%,
  while an 85%-competent student passes ~82% on a single attempt (and reassessment covers the rest).
  8/10 is a good threshold there; 7/10 lets the coin-flipper through ~17% of the time. Compute the
  actual numbers for the instructor's chosen *n* and *k* rather than asserting a rule of thumb.
- **Defeat the elimination shortcut.** If one answer option is almost never correct (e.g., "stays
  the same" in a property-change grid), a lazy student ignores it and effectively faces *k*−1
  options, raising the guessing pass rate. Salt in a *genuine* fraction of items where that option
  IS correct — real invariants (e.g., quantities conserved across the process) — so the option
  can't be dismissed. This also tests a real conceptual distinction. Cap them at a sensible share
  (e.g., ≤3 of 10) so the reverse doesn't happen.
- **Assemble versions under explicit overlap constraints.** If the instructor wants N versions with
  limited item reuse ("no two versions share more than 4 items"), enforce it with a constraint
  search in code, not by eye — and also require phenomenon/topic coverage in every version. A short
  solver that samples until all pairwise overlaps and coverage targets are met is reliable; hand
  assembly silently violates the constraint.
- Note the pool's natural scarcity: genuine-invariant items are usually few, so they recur across
  versions more than change-items do. That's fine as long as the overlap constraint still holds.

**Type B — open-reasoning judgment** (e.g., "assess a design trade-off," "evaluate a propulsion
design choice"). Here there's no single provably-correct answer; the item asks for a defensible
argument. These can't use a verified answer key — they need a **short rubric per item** describing
what a sound justification must contain (the relevant trade-off named, a correct directional
claim, a reason grounded in the physics). Met/not-yet is judged against the rubric. Design these
with the instructor, since what counts as "defensible" is their call.

The tell for which type you have: can you *compute or prove* the correct answer to each item? Yes →
Type A (count-based, verifiable). No → Type B (rubric-based). A single standard is usually all one
type; if it's mixed, split the assessment accordingly.

## Anti-patterns

- Splitting one skill into "forward" and "reverse" standards.
- A standard so broad a single problem can't exercise it (student passes on the easy half).
- Scope notes that only restate the "I can" sentence — they must add specification.
- Certifying tool use that you then can't proctor.
- Letting a standalone-trivial standard sit unexamined; either give it real content (resolution 2)
  or consciously accept it as easy (resolution 1).
- Setting a judgment-bundle pass threshold by feel instead of the guessing math, or leaving an
  answer option that's never correct so students can eliminate it and coin-flip the rest.
- Computing bank answers under an assumed convention (friction factor, γ, ratio direction) without
  confirming which one the course teaches.
