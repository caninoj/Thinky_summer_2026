# Scheduling & Reassessment Logistics

The calendar is where a standards-based course most often breaks. The central ideas:

## The end-of-term squeeze is a conservation problem

Whatever standard is **taught last** gets the **least reassessment runway** before the term
ends. You cannot eliminate this — some standard is always last. The design question is not
"how do I remove the squeeze" but **"which standard can best tolerate being squeezed?"**

The move: use teaching sequence deliberately to push the squeeze onto a **crunch-tolerant,
lower-priority** standard, and protect your **priority** standards by teaching them earlier so
they debut earlier and get the most reassessment cycles.

- A standard you're willing to let some students miss (and that nothing downstream depends on)
  is the ideal last-taught, squeeze-absorbing standard.
- Your priority / capstone standards should debut as early as the prerequisite chain allows,
  buying them the maximum number of reassessment windows before the final.

Beware: moving one standard earlier pushes another later. Trace where the squeeze *goes* — you
want it landing on the crunch-tolerant standard, not merely relocated onto another priority one.

## Prerequisite analysis drives resequencing

Before reordering, verify the dependency chain from the actual lecture materials, not the
catalog. A topic can often move much earlier than its traditional slot if it only depends on
early material plus one small input from an intermediate topic. (Example: airbreathing cycle
analysis depends on early compressible-flow relations plus a single value — the fuel heating
value — from combustion, and nothing from rockets, so it can be taught before rockets to protect
the cycle standards.) Look specifically for:

- **False dependencies:** topics assumed to need each other that actually don't.
- **Thin dependencies:** a whole module that only needs one number or one concept from another —
  teach that one thing as a bridge and move the module.
- **Soft callbacks:** places an earlier lecture says "we'll handle this later." These constrain
  reordering only if the referenced topic would move before the callback.

## Exam batching and the "taught by then" check

First attempts are usually **batched into exam events** (evening exams, or class-period exams).
For each exam, list the standards it will assess and **verify every one has been fully taught by
that date.** The most common scheduling bug is an exam scheduled one lecture too early, so the
last topic on it isn't finished. Check the lecture calendar against the batch, standard by standard.

A batch's size can be uneven across exams — that's fine. What matters is that (a) nothing is
assessed before it's taught, and (b) priority standards don't all pile onto the last exam.

## The reassessment window

Beyond the batch exams, run a **recurring weekly reassessment window** (e.g., a staffed evening
slot). This is where re-attempts happen and where late-taught standards get their first attempts.
Staff it more heavily in the final weeks, where first attempts of the last-taught standard and
reassessments of the priority standards concentrate.

## The reassessment-only final

A final exam slot repurposed as **reassessment-only** (no new first-attempt material) is an
excellent safety net: it's the natural late-clear venue for the squeeze-absorbing standard and
the last reassessment for everyone else. It uses capacity you already have rather than adding
schedule.

## Compression-relief levers (without stealing runway from priority standards)

When a late standard is genuinely compressed (e.g., 8 weeks of material in 2), relieve it without
touching the priority standards' runway:

- **Scope the standard tightly** to its core competency; push advanced sub-topics explicitly
  out of certified scope (record this in the scope note).
- **Improve the provided practice** for that standard (more scaffolded, worked-example-style)
  rather than adding class time.
- **Funnel it to the reassessment-only final** as its primary late-clear path.
- **Free class time upstream** — e.g., move genuinely-review first-week material to pre-class
  video and use class time for problems, buying back a day for the crunched topic.

## Fixed-date hygiene

Anchor the calendar to the real academic calendar: institutional breaks, the last day of
classes, any "quiet period," and the registrar's final-exam slot (which may be TBD — mark it so).
Standalone evening exams don't need to fall on class days, which frees date choices; but confirm
that with the instructor rather than assuming.
