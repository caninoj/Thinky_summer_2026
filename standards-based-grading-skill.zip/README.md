# Standards-Based Grading — a reusable Claude Skill for course redesign

Companion deliverable to the Thinky submission
*"Breaking the Three Bottlenecks That Stop Faculty From Adopting Mastery Grading."*

This is a **portable Claude Skill**: a written method that turns Claude into a
structured design partner for converting a quantitative course from traditional
points-based grading to standards-based / specifications ("mastery") grading in
the *Grading for Growth* tradition (Clark & Talbert).

It was distilled from a complete, real redesign of AAE 33700 (Aerospace
Propulsion Foundations, Purdue — 204 students growing to 350), so it encodes the
**decisions and their reasoning**, not just templates.

## Why this exists

Standards-based grading is well-evidenced pedagogy that faculty largely don't
adopt — not because they doubt it, but because implementation cost is
prohibitive. Carberry, Siniawski, Atwood & Diefes-Dux (ASEE 2016, "Best
Practices for Using Standards-based Grading in Engineering Courses") surveyed
ten engineering instructors at six institutions and found six obstacles. Three
dominate at scale:

1. **Increased initial faculty workload** — the design lift is large and unfamiliar.
2. **CMS/LMS fit** — mainstream gradebooks compute points, not bundle rules.
3. **Score consistency** across instructors, TAs, and graders.

Add the structural burden: their own best-practice list says assess each
objective *multiple times per term*, and Talbert notes that unlike writing
standards, building in reassessment creates real downstream work. Every retake
needs a fresh, equivalent problem.

This skill attacks all three.

## What's inside

    standards-based-grading/
        SKILL.md                         the method: 7 phases, entry points, working style
        references/
            standards_design.md          writing standards, scope notes, the purity principle,
                                         and the decision procedure for standards that
                                         resist standing alone
            grade_structure.md           bundles, the ladder, pass-gates, the percentage trap
            scheduling_reassessment.md   the conservation-of-squeeze problem, exam batching
            lms_setup.md                 the gradebook-as-status-board model
            problem_banks.md             equivalent verified problem-version banks

## How to use it

1. **Load the skill.** Put the `standards-based-grading/` folder where your Claude
   environment reads skills, or paste `SKILL.md` into a conversation and say
   *"Use this method to help me redesign my course."*
2. **Bring your real materials:** syllabus, lecture slides, and two or three past
   exams. The method starts from what your course *actually assesses*, not the
   catalog description.
3. **Work the phases in order:** standards design → Foundational/Applied
   classification → proficiency scale & attempt mechanics → grade ladder →
   sequencing & reassessment logistics → LMS setup → problem banks.
4. **Stay at the fork.** Claude surfaces the tradeoff and recommends; you decide.
   You own content and values.
5. **Verify numerically.** For problem banks, have answers computed in code and
   reconciled to the exact reference tables your students use.

## Three lessons that transfer

- **It's iterative — not one prompt and done.** First drafts were wrong. One
  problem bank was framed from assumed product moles instead of reactant feeds;
  another shipped six near-identical versions and was rebuilt twice; difficulty
  came in too low more than once. The quality lived in the revision passes.
- **Verify numerically, always.** LLM arithmetic on engineering tables looks
  right and is often subtly wrong. Compute in code; reconcile to the table.
  Confirm conventions (Darcy vs. Fanning, γ, ratio direction) *before* generating
  — a wrong convention makes every answer systematically wrong while looking fine.
- **De-scaffolding is a requirement, not a style choice.** The moment a prompt
  names the solution method, it stops testing mastery.

## AI tool used

Claude (Anthropic), across a multi-session redesign spanning course design,
grading structure, LMS configuration, and problem-bank generation.
